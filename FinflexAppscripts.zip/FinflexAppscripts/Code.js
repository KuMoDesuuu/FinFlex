function doGet(e)
{
   //var output = HtmlService.createTemplateFromFile('login');
   //var sess = getSession();
   //if (sess.loggedIn) {

      let page = e.parameter.page;         //01
      if (page == null) page = "index";     //02
      var output = HtmlService.createTemplateFromFile(page); //03
  //}
  return output.evaluate();  //04
}

function includeHeader()   //05
{
   return HtmlService.createTemplateFromFile("header.html").evaluate().getContent();
}

function myURL()  //06
{
  return ScriptApp.getService().getUrl();
}

//creation into database
//customerID || customerName || customerContactNumber || customerAddress || customerEmail || customerNotes
function saveCustomerDetails(customer) {
  var sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Customer Database');
  var customerID = generateUniqueID('Customer Database', 1, 'C');
  sheet.appendRow([customerID, customer.name, customer.contact, customer.address, customer.email, customer.notes]);
}

//supplierID || supplierName || supplierContactNumber || supplierAddress || supplierEmail
function saveSupplierDetails(supplier) {
  var sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Supplier Database');
  var supplierID = generateUniqueID('Supplier Database', 1, 'S');
  sheet.appendRow([supplierID, supplier.name, supplier.contact, supplier.address, supplier.email]);
}

// productID || productSKU || productName || productDescription || productPrice || productStock
function saveProductDetails(product) {
  var sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Product Database');
  var productID = generateUniqueID('Product Database', 1, 'P');
  sheet.appendRow([productID, product.sku, product.name, product.description, product.price, product.stock]);
}

// inventoryID || inventoryName || inventoryAmount || inventoryMinLimit || inventoryMinOrder || supplierID
function saveInventoryDetails(inventory) {
  var sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Inventory Database');
  var inventoryID = generateUniqueID('Inventory Database', 1, 'INVT');
  
  // Use the 'inventory' parameter for all references
  sheet.appendRow([
    inventoryID,          // inventoryID
    inventory.name,       // inventoryName
    inventory.amount,     // inventoryAmount
    inventory.minLimit,   // inventoryMinLimit
    inventory.minLimitOrder, // inventoryMinOrder
    inventory.supplierID  // supplierID
  ]);
}

// procurementID || inventoryID || inventoryName || orderedInventoryQuantity || inventoryUnitPrice || procurementURL || supplierID || receiptID || receiptURL || supplierName || supplierEmail || approvalStatus || paymentStatus

//save procurement details 
function saveProcurementDetails(inventoryID, orderedAmount) {
  var spreadsheetId = '1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs';
  var procurementSheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Procurement Database');
  var inventorySheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Inventory Database');

  // Retrieve inventory details
  var inventoryData = inventorySheet.getDataRange().getValues();
  var inventoryRow;
  var inventoryName;
  var inventoryUnitPrice = 0;
  var supplierID = '';
  var supplierName = '';
  var supplierEmail = '';

  // Find the row for the given inventoryID
  for (var i = 1; i < inventoryData.length; i++) {
    if (inventoryData[i][0] === inventoryID) {
      inventoryRow = inventoryData[i];
      inventoryName = inventoryRow[1]; // Adjust column index as needed
      supplierID = inventoryRow[5]; // Adjust column index as needed
      supplierName = inventoryRow[6]; // Adjust column index as needed
      supplierEmail = inventoryRow[7]; // Adjust column index as needed
      break;
    }
  }

  if (!inventoryRow) {
    Logger.log('Inventory ID not found.');
    return;
  }

  // Retrieve existing procurement orders
  var data = procurementSheet.getDataRange().getValues();
  var openOrderIDs = [];
  var allOrdersApprovedAndPaid = true;

  // Iterate through existing data to find procurement orders for the same supplier
  for (var i = 1; i < data.length; i++) {
    var row = data[i];
    var procurementOrderID = row[0];
    var orderSupplierID = row[6];
    var approvalStatus = row[11];
    var paymentStatus = row[12];
    
    if (orderSupplierID === supplierID) {
      // Check if the order is not approved or paid
      if (approvalStatus !== 'Approved' || paymentStatus !== 'Paid') {
        openOrderIDs.push(procurementOrderID);
        allOrdersApprovedAndPaid = false; // Set flag to false if any order is not approved or paid
      }
    }
  }

  // Determine the procurement order ID to use
  var procurementOrderID = allOrdersApprovedAndPaid 
    ? generateUniqueID('Procurement Database', 1, 'PO') 
    : (openOrderIDs.length > 0 ? openOrderIDs[0] : generateUniqueID('Procurement Database', 1, 'PO'));

  // Append the new procurement details to the sheet
  procurementSheet.appendRow([
    procurementOrderID,      // procurementID
    inventoryID,             // inventoryID
    inventoryName,         // inventoryName
    orderedAmount,       // orderedInventoryQuantity 
    inventoryUnitPrice,      // inventoryUnitPrice
    '',                      // procurementURL (default to empty if not provided)
    supplierID,              // supplierID
    '',                      // receiptID (default to empty if not provided)
    '',                      // receiptURL (default to empty if not provided)
    supplierName,            // supplierName
    supplierEmail,           // supplierEmail
    'Pending',               // approvalStatus (default to 'Pending')
    'Unpaid'                 // paymentStatus (default to 'Unpaid')
  ]);

  Logger.log('Procurement order created with ID: ' + procurementOrderID);
}

// saleID || customerID || customerName || productSKU || productName || productQuantity || unitPrice || totalAmount || paymentMethod || paymentStatus || invoiceID || invoiceURL || receiptID || receiptURL || saleDateTime || customerEmail
function saveSaleDetails(sale) {
  try {
    var spreadsheetId = '1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs';  // Your Spreadsheet ID

    // Get the current date and time
    var now = new Date();
    var formattedDate = Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');

    Logger.log('Formatted Date: ' + formattedDate);
    Logger.log('Sale Data: ' + JSON.stringify(sale));

    // Retrieve customer email from Customer Database
    var customerSheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Customer Database');
    var customerData = customerSheet.getDataRange().getValues();
    var customerEmail = '';
    for (var i = 1; i < customerData.length; i++) {
      if (customerData[i][0] == sale.customerID) {  // Assuming customerID is the key (first column)
        customerEmail = customerData[i][4];  // Assuming the email is in the 5th column (index 4)
        break;
      }
    }

    if (!customerEmail) {
      throw new Error('Customer email not found');
    }

    Logger.log('Customer Email: ' + customerEmail);

    // Generate a unique sale ID
    var saleID = generateUniqueID('Sales Database', 1, 'SL');

    // Save sale details to Sales Database sheet
    var salesSheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Sales Database');
    var rowsToUpdate = [];

    sale.productInfo.forEach(function(product) {
      var row = [
        saleID,                         // saleID
        sale.customerID,                // customerID
        sale.customerName,              // customerName
        product.sku,                    // productSKU
        product.name,                   // productName
        product.quantity,               // productQuantity
        product.unitPrice,              // unitPrice
        product.totalAmount,            // totalAmount
        sale.paymentMethod || 'N/A',    // paymentMethod (use 'N/A' if not available)
        sale.paymentStatus || 'Unpaid', // paymentStatus (default to 'Unpaid' if not available)
        '',                             // invoiceID (to be filled later)
        '',                             // invoiceURL (to be filled later)
        '',                             // receiptID (to be filled later)
        '',                             // receiptURL (to be filled later)
        formattedDate,                  // saleDateTime
        customerEmail                   // customerEmail
      ];
      rowsToUpdate.push(row);
    });

    // Add rows to the sheet
    salesSheet.getRange(salesSheet.getLastRow() + 1, 1, rowsToUpdate.length, rowsToUpdate[0].length).setValues(rowsToUpdate);

    // Verify the rows were added
    Logger.log('Rows added: ' + JSON.stringify(rowsToUpdate));
    
    // Return the invoice URL and ID
    return { saleID: saleID, saleInfo: sale};
  } catch (error) {
    Logger.log('Error: ' + error.message);
    throw error;
  }
}


//generation
//generate invoice 
function generateInvoice(saleId, sale) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  var dataRange = sheet.getDataRange();
  var data = dataRange.getValues();
  var headers = data.shift(); // Remove header row

  var saleID = saleId;
  var customerName = sale.customerName;
  var invoiceID = generateUniqueID('Sales Database', 11, 'INV');

  Logger.log('Sale ID: ' + saleID + ' | Customer Name: ' + customerName + ' | Invoice ID: ' + invoiceID);
  
  var saleOrder = {
    id: saleID,
    customerID: sale.customerID,
    productInfo: [],
    totalAmountBefore: 0
  };

  data.forEach(function(row) {
    var saleIDSS = row[0];
    var productSKU = row[3];
    var productName = row[4];
    var quantity = Number(row[5]);
    var unitPrice = Number(row[6]);
    var paymentStatus = row[9];

    Logger.log('Checking Sale ID: ' + saleIDSS + ' | Payment Status: ' + paymentStatus);
    
    if(saleIDSS === saleID && paymentStatus === 'Unpaid') {
      var totalAmount = quantity * unitPrice;
      saleOrder.productInfo.push({
        sku: productSKU,
        name: productName,
        quantity: quantity,
        unitPrice: unitPrice,
        totalAmount: totalAmount
      });

      saleOrder.totalAmountBefore += totalAmount;
    }
  });

  Logger.log('Sale Order: ' + JSON.stringify(saleOrder));

  if (saleOrder.productInfo.length > 0) {
    var doc = DocumentApp.create('Invoice for ' + customerName);
    var body = doc.getBody();
    
    body.appendParagraph('Invoice ID: #' + invoiceID).setHeading(DocumentApp.ParagraphHeading.HEADING1);
    
    saleOrder.productInfo.forEach(function(product) {
      body.appendParagraph('Product SKU: ' + product.sku);
      body.appendParagraph('  - Name: ' + product.name);
      body.appendParagraph('  - Quantity: ' + product.quantity);
      body.appendParagraph('  - Unit Price: $' + product.unitPrice.toFixed(2));
      body.appendParagraph('  - Total Amount: $' + product.totalAmount.toFixed(2));
    });

    var taxFee = 0.06 * saleOrder.totalAmountBefore;
    var shippingFee = saleOrder.productInfo.reduce((sum, product) => sum + product.quantity, 0) > 20 ? 50 : 75;
    var totalAmountAfter = saleOrder.totalAmountBefore + shippingFee + taxFee;
    
    body.appendParagraph('Total Amount Before: $' + saleOrder.totalAmountBefore.toFixed(2));
    body.appendParagraph('Shipping Fee: $' + shippingFee.toFixed(2));
    body.appendParagraph('Tax Amount (6% GST): $' + taxFee.toFixed(2));
    body.appendParagraph('Total Amount After: $' + totalAmountAfter.toFixed(2));
    body.appendParagraph('Payment Status: Unpaid');

    var docUrl = doc.getUrl();
    var docID = doc.getId();
    Logger.log('Invoice(DOC) created: ' + docUrl);
    var pdfVersion = saveDocAsPDFFromID(docID, 'Google Hackathon PDFs Folder');
    var pdfID = pdfVersion.pdfID;
    var pdfURL = pdfVersion.pdfURL;
    Logger.log('Invoice(PDF) URL: ' + pdfURL);
    
    DriveApp.getFileById(docID).setTrashed(true);
    Logger.log('Invoice (Doc) deleted.');

    return { invoiceID: invoiceID, pdfUrl: pdfURL , pdfID: pdfID};
  } else {
    Logger.log('No unpaid items found for sale ID: ' + saleID);
    return null;
  }
}

function combineSaveSaleAndGenerate(sale){
  var salesSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  var dataRange = salesSheet.getDataRange();
  var data = dataRange.getValues();
  var headers = data.shift(); // Remove header row

  var saleDetails = saveSaleDetails(sale);
  var saleID = saleDetails.saleID;
  var saleInfo = saleDetails.saleInfo;
  
  // Generate invoice after saving all sale details
  var invoiceResult = generateInvoice(saleID, sale);
  if (!invoiceResult) {
    Logger.log('Failed to generate invoice.');
    return { invoiceUrl: null };
  }

  var invoiceID = invoiceResult.invoiceID;
  var invoicePDFURL = invoiceResult.pdfUrl;
  var invoicePDFID = invoiceResult.pdfID;

  // Update the invoiceID and invoiceURL in the Sales Database sheet for all rows with the same saleID
  var range = salesSheet.getRange(2, 1, salesSheet.getLastRow(), 1); // Get all rows in the first column (saleID)
  var values = range.getValues();
  for (var i = 0; i < values.length; i++) {
    if (values[i][0] === saleID) {
      var rowIndex = i + 2; // Adjust for header and 0-based index
      salesSheet.getRange(rowIndex, 11).setValue(invoiceID); // Invoice ID
      salesSheet.getRange(rowIndex, 12).setValue(invoicePDFURL); // Invoice URL
    }
  }

  // Send the invoice to the customer
  sendInvoiceToCustomer(saleID, invoicePDFID, invoicePDFURL, invoiceID);

  // Return the invoice URL and ID
  return { saleID: saleID, invoiceUrl: invoicePDFURL, saleInfo: sale, invoiceID: invoiceID, invoicePDFID: invoicePDFID};
}

//generate receipt sale
function generateReceiptsSale(saleID, customerID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row

  var customerOrder = {
    name: '',
    productInfo: [],
    totalItems: 0,
    totalAmountBefore: 0
  };

  // saleID || customerID || customerName || productSKU || productName || productQuantity || unitPrice || totalAmount || paymentMethod || paymentStatus || invoiceID || invoiceURL || receiptID || receiptURL

  data.forEach(function(row, index) {
    var saleIDSS = row[0];
    var customerIDSS = row[1];
    var customerName = row[2];
    var productSKU = row[3];
    var productName = row[4];
    var quantity = row[5];
    var unitPrice = row[6];
    
    if (saleIDSS === saleID && customerIDSS === customerID) {
      if (!customerOrder.name) {
        customerOrder.name = customerName;
      }

      var totalAmount = quantity * unitPrice;

      customerOrder.productInfo.push({
        sku: productSKU,
        name: productName,
        quantity: quantity,
        unitPrice: unitPrice,
        totalAmount: totalAmount
      });

      customerOrder.totalItems += quantity;
      customerOrder.totalAmountBefore += totalAmount;

      // Update payment status in the sheet (column 9, index 8)
      sheet.getRange(index + 2, 10).setValue('Paid');
    }
  });

  // Generate receipt
  if (customerOrder.name) {
    var uniqueReceiptID = generateUniqueID('Sales Database', 13, 'SR');
    var doc = DocumentApp.create('Receipt for ' + customerOrder.name);
    var body = doc.getBody();
    
    body.appendParagraph('Receipt ID: #' + uniqueReceiptID).setHeading(DocumentApp.ParagraphHeading.HEADING1);
    
    customerOrder.productInfo.forEach(function(product) {
      body.appendParagraph('Product SKU: ' + product.sku);
      body.appendParagraph('  - Name: ' + product.name);
      body.appendParagraph('  - Quantity: ' + product.quantity);
      body.appendParagraph('  - Unit Price: $' + product.unitPrice.toFixed(2));
      body.appendParagraph('  - Total Amount: $' + product.totalAmount.toFixed(2));
    });

    var taxFee = 0.06 * customerOrder.totalAmountBefore;
    var shippingFee = customerOrder.totalItems > 20 ? 50 : 75;
    var totalAmountAfter = customerOrder.totalAmountBefore + taxFee + shippingFee;
    
    body.appendParagraph('Total Amount Before: $' + customerOrder.totalAmountBefore.toFixed(2));
    body.appendParagraph('Shipping Fee: $' + shippingFee.toFixed(2));
    body.appendParagraph('Tax Amount (6% GST): $' + taxFee.toFixed(2));
    body.appendParagraph('Total Amount After: $' + totalAmountAfter.toFixed(2));
    body.appendParagraph('Payment Status: Paid');

    var docUrl = doc.getUrl();
    var docID = doc.getId();
    Logger.log('Receipt(DOC) created: ' + docUrl);
    var pdf = saveDocAsPDFFromID(docID, 'Google Hackathon PDFs Folder');
    var pdfID = pdf.pdfID;
    var pdfUrl = pdf.pdfURL;
    Logger.log('Receipt(PDF) URL: ' + pdfUrl);
    
    // DriveApp.getFileById(doc.getId()).setTrashed(true);
    // Logger.log('Receipt (Doc) deleted.');

    // Update the spreadsheet with the receipt URL and ID
    data.forEach(function(row, index) {
      if (row[0] === saleID && row[1] === customerID) {
        var rowIndex = index + 2;
        sheet.getRange(rowIndex, 13).setValue(uniqueReceiptID); // Receipt ID in the 13th column (index 12)
        sheet.getRange(rowIndex, 14).setValue(pdfUrl); // Receipt URL in the 14th column (index 13)
      }
    });
    return { pdfUrl: pdfUrl, receiptID: uniqueReceiptID , pdfID: pdfID};
  } else {
    Logger.log('No matching sale and customer found.');
    return null;
  }
}
function deductStockFromSale(saleID) {
  var spreadsheetId = '1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs'; // Your Spreadsheet ID
  var salesSheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Sales Database');
  var productSheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Product Database');
  
  var salesData = salesSheet.getDataRange().getValues();
  var productData = productSheet.getDataRange().getValues();
  var productHeaders = productData.shift(); // Remove header row

  var productMap = {};
  
  // Create a map of product SKU to row index in product sheet
  productData.forEach(function(row, index) {
    var productSKU = row[1]; // Assuming Product SKU is in the second column
    productMap[productSKU] = index + 2; // Save row index (adjust for header)
  });

  salesData.forEach(function(row) {
    var saleIDSS = row[0];
    var productSKU = row[3];
    var quantity = Number(row[5]);
    var paymentStatus = row[9];
    var receiptID = row[12];
    var receiptURL = row[13];

    Logger.log('Checking Sale ID: ' + saleIDSS + ' | Payment Status: ' + paymentStatus);
    
    if (saleIDSS === saleID && paymentStatus === 'Paid' && receiptID && receiptURL) {
      if (productMap[productSKU] !== undefined) {
        var productRowIndex = productMap[productSKU];
        var currentStock = productSheet.getRange(productRowIndex, 6).getValue(); // Assuming Product Stock is in the sixth column
        Logger.log('Current Stock for Product SKU ' + productSKU + ': ' + currentStock);
        
        var newStock = currentStock - quantity;
        Logger.log('New Stock for Product SKU ' + productSKU + ': ' + newStock);
        
        productSheet.getRange(productRowIndex, 6).setValue(newStock);
        Logger.log('Stock updated for Product SKU: ' + productSKU + ' | New Stock: ' + newStock);
      } else {
        Logger.log('Product SKU not found in Product Database: ' + productSKU);
      }
    }
  });
}


//Generate Procurement Order
// Function to generate procurement order
function generateProcurementOrder(procurementID, supplierID, companyName) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row
  
  var supplierOrders = {};
  var affectedRows = [];
  
  // Map data to supplier orders
  data.forEach(function(row, index) {
    var procurementIDSS = row[0];
    var inventoryID = row[1];
    var inventoryName = row[2];
    var orderedInventoryQuantity = row[3];
    var inventoryUnitPrice = row[4];
    var procurementURL = row[5];
    var supplierId = row[6];
    var supplierName = row[9];
    var supplierEmail = row[10];
    
    if (procurementIDSS === procurementID && supplierId === supplierID) {
      if (!supplierOrders[supplierId]) {
        supplierOrders[supplierId] = {
          productInfo: [],
          supplierID: supplierID,
          name: supplierName,
          email: supplierEmail
        };
      }
      
      supplierOrders[supplierId].productInfo.push({
        inventoryID: inventoryID,
        inventoryName: inventoryName,
        orderedQuantity: orderedInventoryQuantity,
        unitPrice: inventoryUnitPrice
      });
      
      affectedRows.push(index + 2); // Adjusted for headers and 1-based index
    }
  });

  // Generate order document
  var supplier = supplierOrders[supplierID];
  if (supplier) {
    var doc = DocumentApp.create('Procurement Order for ' + supplier.name + ' || #' + procurementID);
    var body = doc.getBody();
    
    body.appendParagraph('Order Number: #' + procurementID).setHeading(DocumentApp.ParagraphHeading.HEADING1);
    body.appendParagraph('To: ' + supplier.name);
    
    supplier.productInfo.forEach(function(product) {
      body.appendParagraph('Inventory ID: ' + product.inventoryID);
      body.appendParagraph('  - Inventory Name: ' + product.inventoryName);
      body.appendParagraph('  - Quantity Ordered: ' + product.orderedQuantity);
      body.appendParagraph('  - Unit Price: ' + product.unitPrice);
    });

    body.appendParagraph('Sincerely, ' + companyName);

    var docUrl = doc.getUrl();
    var docID = doc.getId();
    Logger.log('Order (DOC) created: ' + docUrl);
    
    var pdf = saveDocAsPDFFromID(docID, 'Google Hackathon PDFs Folder'); // Convert the Google Doc to PDF and get the URL
    var pdfId = pdf.pdfID;
    var pdfUrl = pdf.pdfURL;
    Logger.log('Order (PDF) URL: ' + pdfUrl);
    
    // Uncomment this line if you want to delete the document after creating the PDF
    // DriveApp.getFileById(doc.getId()).setTrashed(true); 

    Logger.log('Procurement order (Doc) deleted.');

    // Update the procurement URL in the sheet
    affectedRows.forEach(function(row) {
      sheet.getRange(row, 6).setValue(pdfUrl); // Update the procurement URL in the 7th column (index 6)
    });

    return {
      procurementID: procurementID,
      pdfID: pdfId,
      pdfUrl: pdfUrl
    };
  }
  return null;
}

//generate receipt for procurement
function generateReceiptsProcurement(procurementID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database'); 
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row

  var uniqueReceiptID = generateUniqueID('Procurement Database', 8, 'PR');
  var totalAmountBefore = 0;
  var totalItems = 0;
  var supplierName = "";
  var supplierEmail = "";
  var items = [];

  // procurementID || inventoryID || inventoryName || orderedInventoryQuantity || inventoryUnitPrice || procurementURL || supplierID || receiptID || receiptURL || supplierName || supplierEmail || approvalStatus || paymentStatus
  data.forEach(function(row, index) {
    var procurementIDSS = row[0];
    var inventoryID = row[1];
    var inventoryName = row[2];
    var orderedQuantity = row[3];
    var unitPrice = row[4];
    var supplierID = row[6];
    var supplierNameData = row[9];
    var supplierEmailData = row[10];
    var approvalStatus = row[11];

    if (procurementIDSS === procurementID && approvalStatus === 'Approved') {
      if (!supplierName) {
        supplierName = supplierNameData;
        supplierEmail = supplierEmailData;
      }

      var totalAmount = orderedQuantity * unitPrice;
      items.push({
        id: inventoryID,
        name: inventoryName,
        quantity: orderedQuantity,
        unitPrice: unitPrice,
        totalAmount: totalAmount
      });

      totalItems += orderedQuantity;
      totalAmountBefore += totalAmount;

      // Update the payment status and receipt ID in the sheet
      sheet.getRange(index + 2, 13).setValue('Paid'); // Payment status in the 12th column (index 11)
      sheet.getRange(index + 2, 8).setValue(uniqueReceiptID); // Receipt ID in the 8th column (index 7)
    }
  });

  // Generate a single receipt document
  var doc = DocumentApp.create('Receipt for Procurement Order #' + procurementID);
  var body = doc.getBody();

  body.appendParagraph('Receipt ID: #' + uniqueReceiptID).setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendParagraph('Procurement Order ID: #' + procurementID);
  body.appendParagraph('Supplier: ' + supplierName);

  items.forEach(function(item) {
    body.appendParagraph('Product ID: ' + item.id);
    body.appendParagraph('  - Name: ' + item.name);
    body.appendParagraph('  - Quantity: ' + item.quantity);
    body.appendParagraph('  - Unit Price: $' + item.unitPrice.toFixed(2));
    body.appendParagraph('  - Total Amount: $' + item.totalAmount.toFixed(2));
  });

  var taxFee = 0.06 * totalAmountBefore;
  var shippingFee = totalItems > 100 ? 50 : 75;
  var totalAmountAfter = totalAmountBefore + taxFee + shippingFee;

  body.appendParagraph('Total Amount Before: $' + totalAmountBefore.toFixed(2));
  body.appendParagraph('Shipping Fee: $' + shippingFee.toFixed(2));
  body.appendParagraph('Tax Amount (6% GST): $' + taxFee.toFixed(2));
  body.appendParagraph('Total Amount After: $' + totalAmountAfter.toFixed(2));
  body.appendParagraph('Payment Status: Paid');

  var docUrl = doc.getUrl();
  var docID = doc.getId();
  Logger.log('Receipt (DOC) created: ' + docUrl);
  var pdf = saveDocAsPDFFromID(docID, 'Google Hackathon PDFs Folder');
  var pdfId = pdf.pdfID;
  var pdfUrl = pdf.pdfURL;
  Logger.log('Receipt (PDF) URL: ' + pdfUrl);

  // DriveApp.getFileById(doc.getId()).setTrashed(true);
  // Logger.log('Receipt (Doc) deleted.');

  // Update the spreadsheet with the receipt URL
  data.forEach(function(row, index) {
    if (row[0] === procurementID && row[11] === 'Approved') {
      sheet.getRange(index + 2, 9).setValue(pdfUrl); // Receipt URL in the 9th column (index 8)
    }
  });

  return {
    procurementID: procurementID,
    receiptID: uniqueReceiptID,
    pdfUrl: pdfUrl,
    pdfID: pdfId
  };
}

function getRestockData() {
  const sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Restock Database');
  return sheet.getDataRange().getValues().slice(1); // Exclude header row
}
 
function approveRestock(id) {
  // This function is intentionally left empty as per requirements
}
 
function rejectRestock(id) {
  const sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Restock Database');
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === id) {
      sheet.deleteRow(i + 1); // Delete the row
      break;
    }
  }
}
 
function payRestock(id) {
  const sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Restock Database');
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === id) {
      sheet.deleteRow(i + 1); // Delete the row after payment
      break;
    }
  }
}

function generateMonthlyReportHTML(year, month) {
  const salesData = getSalesDataForMonth(year, month);
  const totalSales = salesData.reduce((acc, row) => acc + row[7], 0); // Assuming total amount is in the 8th column
  const totalTransactions = salesData.length;
  const averageSaleValue = totalSales / totalTransactions;

  const productQuantities = {};
  const dailySales = {};

  salesData.forEach(row => {
    const product = String(row[4]); // Assuming product name is in the 5th column
    const date = new Date(row[14]).toLocaleDateString(); // Assuming date is in the 15th column

    if (!productQuantities[product]) {
      productQuantities[product] = 0;
    }
    productQuantities[product] += row[5]; // Assuming quantity is in the 6th column

    // Total amount
    if (!dailySales[date]) {
      dailySales[date] = 0;
    }
    dailySales[date] += row[7]; // Assuming total amount is in the 8th column
  });

  const mostSoldProduct = Object.keys(productQuantities).reduce((a, b) => productQuantities[a] > productQuantities[b] ? a : b);

  // Generate the charts
  const productQuantitiesChart = generateProductQuantitiesChart(productQuantities);
  const dailySalesChart = generateDailySalesChart(dailySales);

  let reportHTML = `
    <h2>Monthly Sales Report - ${year}-${month}</h2>
    <p>Total Sales: $${totalSales.toFixed(2)}</p>
    <p>Total Transactions: ${totalTransactions}</p>
    <p>Average Sale Value: $${averageSaleValue.toFixed(2)}</p>
    <p>Most Sold Product: ${mostSoldProduct}</p>
    <div>
      <img src="data:image/png;base64,${Utilities.base64Encode(productQuantitiesChart)}" alt="Product Quantities Chart">
      <img src="data:image/png;base64,${Utilities.base64Encode(dailySalesChart)}" alt="Daily Sales Trend">
    </div>
    <h3>Detailed Transactions:</h3>
    <table border="1" style="border-collapse: collapse; width: 100%;">
      <tr>
        <th>Sale ID</th>
        <th>Date</th>
        <th>Customer</th>
        <th>Product Purchased</th>
        <th>Quantity</th>
        <th>Unit Price</th>
        <th>Total Amount</th>
      </tr>
  `;
  salesData.forEach(row => {
    reportHTML += `
      <tr>
        <td>${row[0]}</td> <!-- Assuming SaleID is in the 1st column -->
        <td>${new Date(row[14]).toLocaleString()}</td> <!-- Assuming Date is in the 15th column -->
        <td>${row[2]}</td> <!-- Assuming Customer is in the 3rd column -->
        <td>${row[4]}</td> <!-- Assuming Product Purchased is in the 5th column -->
        <td>${row[5]}</td> <!-- Assuming Quantity is in the 6th column -->
        <td>${row[6].toFixed(2)}</td> <!-- Assuming Unit Price is in the 7th column -->
        <td>${row[7].toFixed(2)}</td> <!-- Assuming Total Amount is in the 8th column -->
      </tr>
    `;
  });

  reportHTML += '</table>';
  return reportHTML;
}

function generateProductQuantitiesChart(productQuantities) {
  const data = Charts.newDataTable();
  data.addColumn(Charts.ColumnType.STRING, 'Product');
  data.addColumn(Charts.ColumnType.NUMBER, 'Quantity');
  Object.keys(productQuantities).forEach(product => {
    data.addRow([product, productQuantities[product]]);
  });

  const chart = Charts.newPieChart()
    .setDataTable(data)
    .setTitle('Product Quantities')
    .setDimensions(600, 400)
    .build();

  return chart.getAs('image/png').getBytes();
}

function generateDailySalesChart(dailySales) {
  const data = Charts.newDataTable();
  data.addColumn(Charts.ColumnType.STRING, 'Date');
  data.addColumn(Charts.ColumnType.NUMBER, 'Total Sales');
  Object.keys(dailySales).forEach(date => {
    data.addRow([date, dailySales[date]]);
  });

  const chart = Charts.newLineChart()
    .setDataTable(data)
    .setTitle('Daily Sales Trend')
    .setDimensions(600, 400)
    .build();

  return chart.getAs('image/png').getBytes();
}

function generateYearlyReportHTML(year) {
  const salesData = getSalesDataForYear(year);
  const totalSales = salesData.reduce((acc, row) => acc + row[3], 0); // Assuming total amount is in the 8th column
  const totalTransactions = salesData.length;
  const averageSaleValue = totalSales / totalTransactions;

  let reportHTML = `
    <h2>Yearly Sales Report - ${year}</h2>
    <p>Total Sales: $${totalSales.toFixed(2)}</p>
    <p>Total Transactions: ${totalTransactions}</p>
    <p>Average Sale Value: $${averageSaleValue.toFixed(2)}</p>
  `;

  // Add monthly data table
  reportHTML += `
    <table>
      <tr>
        <th>Month</th>
        <th>Total Sales</th>
        <th>Number of Transactions</th>
        <th>Revenue</th>
        <th>Payment Status</th>
      </tr>
  `;
  salesData.forEach(row => {
    reportHTML += `
      <tr>
        <td>${row[0]}</td>
        <td>${row[1]}</td>
        <td>${row[2]}</td>
        <td>${row[3].toFixed(2)}</td>
        <td>${row[4]}</td>
      </tr>
    `;
  });
  reportHTML += '</table>';

  return reportHTML;
}

//utilities
//questions
function updateStockLevels(sale) {
  var spreadsheetId = '1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs';  // Your Spreadsheet ID
  var inventorySheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Inventory Database');
  var supplierSheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName('Supplier Database');
  var range = inventorySheet.getDataRange();
  var values = range.getValues();
  
  Logger.log('Update stock levels for product: ' + sale.productInfo);
  Logger.log('Current inventory data: ' + JSON.stringify(values));

  for (var i = 1; i < values.length; i++) {
    Logger.log('Checking product: ' + values[i][1]);
    if (values[i][1] === sale.productInfo) {  // Assuming productInfo matches productName in Inventory Database
      var newStockLevel = parseInt(values[i][3], 10) - parseInt(sale.quantity, 10);
      Logger.log('New stock level for ' + sale.productInfo + ': ' + newStockLevel);
      inventorySheet.getRange(i + 1, 4).setValue(newStockLevel);  // Update stock level in the 4th column
      if (newStockLevel <= values[i][4]) {  // Check if stock level is at or below reorder point
        Logger.log('Stock level for ' + sale.productInfo + ' is at or below reorder point.');
        triggerRestockNotification(values[i][1], supplierSheet);  // Trigger restock notification
      }
      break;
    }
  }
}

function triggerRestockNotification(productName, supplierSheet) {
  Logger.log('Triggering restock notification for product: ' + productName);
  var range = supplierSheet.getDataRange();
  var values = range.getValues();

  for (var i = 1; i < values.length; i++) {
    Logger.log('Checking supplier for product: ' + values[i][1]);
    if (values[i][1] === productName) {  // Assuming productName matches the inventory item
      Logger.log('Supplier found: ' + values[i][2] + ', ' + values[i][3]);
      sendRestockEmail({
        name: values[i][2], 
        email: values[i][3], 
        contact: values[i][4], 
        address: values[i][5]
      }, productName);  // Send restock email to supplier
      break;
    }
  }
}

function checkInventoryLevels() {
  Logger.log('Checking inventory levels...');
  var ss = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs');
  var inventorySheet = ss.getSheetByName('Inventory Database');
  var supplierSheet = ss.getSheetByName('Supplier Database');

  var inventoryData = inventorySheet.getDataRange().getValues();
  var supplierData = supplierSheet.getDataRange().getValues();

  // Loop through the inventory data
  for (var i = 1; i < inventoryData.length; i++) {
    var currentStock = inventoryData[i][2];
    var reorderPoint = inventoryData[i][3];
    var reorderQuantity = inventoryData[i][4];
    var inventoryID = inventoryData[i][0];
    
    if (currentStock <= reorderPoint) {
      Logger.log('Inventory item ' + inventoryItem + ' is at or below reorder point.');
      saveProcurementDetailsAuto(inventoryID, reorderQuantity)
      }
    }
  }

//extract info
function getSupplierInfo(inventoryItem, supplierData) {
  Logger.log('Getting supplier info for item: ' + inventoryItem);
  for (var j = 1; j < supplierData.length; j++) {
    if (supplierData[j][1] === inventoryItem) {
      Logger.log('Supplier found: ' + supplierData[j][2] + ', ' + supplierData[j][3]);
      return {
        name: supplierData[j][1],
        contact: supplierData[j][2],
        address: supplierData[j][3],
        email: supplierData[j][4]
      };
    }
  }
  Logger.log('No supplier found for item: ' + inventoryItem);
  return null;
}

function saveMonthlyReportAsPDF(year, month) {
  const html = generateMonthlyReportHTML(year, month);
  const folder = getOrCreateFolder(`${year} - Monthly Reports`);
  const fileName = `Monthly_Sales_Report_${year}_${month}.pdf`;

  const tempDoc = DocumentApp.create('Temporary Document');
  tempDoc.getBody().setHtmlContent(html);
  const docId = tempDoc.getId();

  // Convert the document to PDF
  const pdf = DriveApp.getFileById(docId).getAs('application/pdf');
  pdf.setName(fileName);
  folder.createFile(pdf);

  // Clean up the temporary document
  DriveApp.getFileById(docId).setTrashed(true);

  return pdf.getUrl();
}

function getSalesDataForMonth(year, month) {
  const sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Sales Database');
  const data = sheet.getDataRange().getValues();
  const filteredData = data.filter(row => {
    const date = new Date(row[14]); // Assuming date is in the 15th column (index 14)
    return date.getFullYear() === parseInt(year) && date.getMonth() + 1 === parseInt(month);
  });
  return filteredData;
}

function getSalesDataForYear(year) {
  const sheet = SpreadsheetApp.openById('1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs').getSheetByName('Sales Database');
  const data = sheet.getDataRange().getValues();
  const monthlyData = {};
  
  data.forEach(row => {
    const date = new Date(row[14]); // Assuming date is in the 15th column (index 14)
    if (date.getFullYear() === parseInt(year)) {
      const month = date.getMonth() + 1;
      if (!monthlyData[month]) {
        monthlyData[month] = {
          totalSales: 0,
          numTransactions: 0,
          revenue: 0,
          paymentStatus: 'Paid' // Default status, adjust as needed
        };
      }
      monthlyData[month].totalSales += 1;
      monthlyData[month].numTransactions += 1;
      monthlyData[month].revenue += row[6]; // Assuming total amount is in the 7th column (index 6)
    }
  });
  
  const result = [];
  for (const month in monthlyData) {
    result.push([
      month,
      monthlyData[month].totalSales,
      monthlyData[month].numTransactions,
      monthlyData[month].revenue,
      monthlyData[month].paymentStatus
    ]);
  }
  return result;
}

function getOrCreateFolder(folderName) {
  const folders = DriveApp.getFoldersByName(folderName);
  if (folders.hasNext()) {
    return folders.next();
  } else {
    return DriveApp.createFolder(folderName);
  }
}

//generate unique ID
function generateUniqueID(sheetName, idColumnNumber, keyword) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  
  // Retrieve the existing IDs from the specified column
  var idRange = sheet.getRange(2, idColumnNumber, sheet.getLastRow() - 1);
  var existingIDs = idRange.getValues().flat();
  
  // Initialize variables to find the highest number
  var highestNumber = 0;

  // Extract numeric part and find the highest number
  for (var i = 0; i < existingIDs.length; i++) {
    var id = existingIDs[i];
    if (id.startsWith(keyword)) {
      var numberPart = id.substring(keyword.length);
      var numericValue = parseInt(numberPart, 10);
      if (numericValue > highestNumber) {
        highestNumber = numericValue;
      }
    }
  }

  // Generate the new unique ID
  var newNumber = (highestNumber + 1).toString().padStart(3, '0');
  var newID = keyword + newNumber;

  Logger.log('New unique ID: ' + newID);
  return newID;
}

//clear row based on a key
function clearItemBasedOnKey(sheetName, key, keyColumn) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  var data = sheet.getDataRange().getValues();
  
  for (var i = data.length - 1; i >= 1; i--) { 
    if (data[i][keyColumn] === key) {
      sheet.deleteRow(i + 1); 
    }
  }
}

//convert doc to pdf
function saveDocAsPDFFromID(docId, folderName) {
  try {
    Logger.log('Attempting to get file by ID: ' + docId);
    
    // Get the document file by its ID
    var docFile = DriveApp.getFileById(docId);

    Logger.log('File retrieved: ' + docFile.getName());

    // Load the document to ensure it's fully loaded
    var doc = DocumentApp.openById(docId);
    doc.saveAndClose();
    
    // Get the file as a PDF blob
    var pdfBlob = docFile.getAs(MimeType.PDF);
    var fileName = docFile.getName() + ' (PDF).pdf';

    Logger.log('PDF blob created with name: ' + fileName);

    // Find the target folder by name
    var folders = DriveApp.getFoldersByName(folderName);
    if (folders.hasNext()) {
      var folder = folders.next();
      Logger.log('Folder found: ' + folder.getName());

      // Create the PDF file in the target folder
      var pdfFile = folder.createFile(pdfBlob).setName(fileName);

      Logger.log('PDF saved as: ' + fileName);

      var pdfID = pdfFile.getId();
      var pdfURL = pdfFile.getUrl();
      
      return {pdfID: pdfID, pdfURL: pdfURL};
    } else {
      Logger.log('Folder not found: ' + folderName);
      return {error: 'Folder not found: ' + folderName};
    }
  } catch (error) {
    Logger.log('Error in saveDocAsPDFFromID: ' + error.message);
    return {error: 'Error: ' + error.message};
  }
}

function sendEmailWithPDF(pdfID, personID, emailSubject, emailBody, companyName) {  

    var pdfFile = DriveApp.getFileById(pdfID);

    if (!personID || !personID.email) {
    Logger.log('Invalid email address.');
    return;
  }
    
    // Email details
    var emailBody = 'Dear ' + personID.name + ',\n\n' + emailBody + 'Sincerely, ' + companyName;
    
    // Send the email with the PDF attachment
    GmailApp.sendEmail(personID.email, emailSubject, emailBody, {
      attachments: [pdfFile.getAs(MimeType.PDF)]
    });
    
    Logger.log('Email sent to: ' + personID.email);
  }

//sending gmails

//approve procurement
function approveProcurement(procurementID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row
  
  var supplierID = null;
  var supplierName = null;
  var supplierEmail = null;
  var matchingRows = []; // Array to store the indices of matching rows

  // Find the supplier ID, name, and email for the given procurement ID
  data.forEach(function(row, index) {
    if (row[0] === procurementID) { // procurementID is in the first column (index 0)
      supplierID = row[6]; // supplierID is in the 7th column (index 6)
      supplierName = row[9]; // supplierName is in the 10th column (index 9)
      supplierEmail = row[10]; // supplierEmail is in the 11th column (index 10)
      matchingRows.push(index + 2); // Store the 1-based index of the row to update later (+2 because of the header row)
    }
  });

  if (matchingRows.length > 0) {
    // Update the status for all matching rows
    matchingRows.forEach(function(rowIndex) {
      sheet.getRange(rowIndex, 12).setValue('Approved'); // approvalStatus is in the 12th column (index 11)
    });
  } else {
    Logger.log('Procurement ID or Supplier information not found.');
    return;
  }

  // Generate procurement order document
  var orderInfo = generateProcurementOrder(procurementID, supplierID, 'Bookstore ABC');
  
  if (orderInfo) {
    var orderPdfUrl = orderInfo.pdfUrl;
    var orderPDFID = orderInfo.pdfID;
    Logger.log('Procurement Order (PDF) URL: ' + orderPdfUrl);
  
    var personID = {
      name: supplierName,
      email: supplierEmail
    };

    var emailBody = 'Your procurement order has been approved. You can download the procurement order from the link below:\n\n';
    emailBody += 'Procurement Order: ' + orderPdfUrl + '\n';

    matchingRows.forEach(function(rowIndex) {
      sheet.getRange(rowIndex, 6).setValue(orderPdfUrl); // approvalStatus is in the 12th column (index 11)
    });
    // Send procurement order to supplier
    sendEmailWithPDF(orderPDFID, personID, 'Your Procurement Order from Bookstore ABC', emailBody, 'Bookstore ABC');


  } else {
    Logger.log('Failed to generate procurement order.');
  }
}

function rejectProcurement(procurementID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row
  
  var supplierID = null;
  var supplierName = null;
  var supplierEmail = null;
  var matchingRows = []; // Array to store the indices of matching rows

  // Find the supplier ID, name, and email for the given procurement ID
  data.forEach(function(row, index) {
    if (row[0] === procurementID) { // procurementID is in the first column (index 0)
      supplierID = row[6]; // supplierID is in the 7th column (index 6)
      supplierName = row[9]; // supplierName is in the 10th column (index 9)
      supplierEmail = row[10]; // supplierEmail is in the 11th column (index 10)
      matchingRows.push(index + 2); // Store the 1-based index of the row to update later (+2 because of the header row)
    }
  });

  if (matchingRows.length > 0) {
    // Update the status for all matching rows
    matchingRows.forEach(function(rowIndex) {
      sheet.getRange(rowIndex, 12).setValue('Rejected'); // approvalStatus is in the 12th column (index 11)
    });
  } else {
    Logger.log('Procurement ID or Supplier information not found.');
    return;
  }
}


//pay procurement
function payProcurement(procurementID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row

  var supplierInfo = {};

  // Find supplier details and update payment status for the given procurement ID
  data.forEach(function(row, index) {
    if (row[0] === procurementID) { // procurementID is in the first column (index 0)
      var supplierID = row[6]; // supplierID is in the 7th column (index 6)
      var supplierName = row[9]; // supplierName is in the 10th column (index 9)
      var supplierEmail = row[10]; // supplierEmail is in the 11th column (index 10)

      if (!supplierInfo[supplierID]) {
        supplierInfo[supplierID] = {
          name: supplierName,
          email: supplierEmail,
        };
      }

      // Update payment status in the sheet
      sheet.getRange(index + 2, 13).setValue('Paid'); // Payment status in the 12th column (index 11)
    }
  });

  // Check if supplier information was found
  if (Object.keys(supplierInfo).length === 0) {
    Logger.log('Procurement ID or Supplier information not found.');
    return;
  }

  // Generate procurement receipt
  var receiptInfo = generateReceiptsProcurement(procurementID);
  var receiptID = receiptInfo.receiptID;

  if(receiptInfo){
    return { receiptID: receiptID };
  } else {
    return 'Procurement Payment Failed';
  }
}

function confirmProcurement(procurementID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row

  var inventoryUpdateInfo = [];

  // Collect inventory update information for the given procurement ID
  data.forEach(function(row, index) {
    if (row[0] === procurementID) { // procurementID is in the first column (index 0)
      var inventoryID = row[1]; // Inventory ID is in the 2nd column (index 1)
      var orderedQuantity = Number(row[3]); // Ordered Quantity is in the 4th column (index 3)
      inventoryUpdateInfo.push({ inventoryID: inventoryID, quantity: orderedQuantity });
    }
  });

  // Update inventory stock
  updateInventoryStock(inventoryUpdateInfo);

  return "Procurement confirmed and inventory updated.";
}

function updateInventoryStock(inventoryUpdateInfo) {
  var inventorySheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Inventory Database');
  var inventoryData = inventorySheet.getDataRange().getValues();
  var headers = inventoryData.shift(); // Remove header row

  var inventoryMap = {};

  // Create a map for easy lookup of inventory data
  inventoryData.forEach(function(row, index) {
    var inventoryID = row[0]; // Inventory ID is in the first column (index 0)
    inventoryMap[inventoryID] = { row: index + 2, amount: Number(row[2]) }; // Inventory Amount is in the 3rd column (index 2)
  });

  // Update the inventory amounts based on the procurement
  inventoryUpdateInfo.forEach(function(update) {
    var inventoryID = update.inventoryID;
    var orderedQuantity = update.quantity;

    if (inventoryMap[inventoryID]) {
      var newAmount = inventoryMap[inventoryID].amount + orderedQuantity;
      inventorySheet.getRange(inventoryMap[inventoryID].row, 3).setValue(newAmount); // Update Inventory Amount in the 3rd column (index 2)
      Logger.log('Updated inventory for ' + inventoryID + ': new amount = ' + newAmount);
    } else {
      Logger.log('Inventory ID ' + inventoryID + ' not found in Inventory Database.');
    }
  });
}

//approve procurement

//send invocie to customer
function sendInvoiceToCustomer(saleID, invoicePDFID, invoicePDFURL, invoiceID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row
  
  var sale = null;

  // Find the sale record by saleID
  data.forEach(function(row) {
    if (row[0] === saleID) { // saleID is in the first column (index 0)
      sale = {
        saleID: row[0],
        customerID: row[1],
        customerName: row[2],
        customerEmail: row[15] // Assuming customerEmail is in the 14th column (index 13)
      };
    }
  });

  if (!sale) {
    Logger.log('Sale ID not found.');
    return;
  }

  // // Generate the invoice
  // var invoiceInfo = generateInvoice(saleID,sale);
  // if (!invoiceInfo) {
  //   Logger.log('Invoice could not be generated.');
  //   return;
  // }

  // Update the spreadsheet with the invoice ID and URL
  data.forEach(function(row, index) {
    if (row[0] === saleID) {
      sheet.getRange(index + 2, 11).setValue(invoiceID); // Invoice ID in the 11th column (index 10)
      sheet.getRange(index + 2, 12).setValue(invoicePDFURL); // Invoice URL in the 12th column (index 11)
    }
  });

  var personID = {
    name: sale.customerName,
    email: sale.customerEmail
  };

  var emailBody = 'Dear ' + sale.customerName + ',\n\nThank you for your purchase. Attached is your invoice. You can download it using the link below:\n\n' +
                  'Invoice: ' + invoicePDFURL + '\n\nSincerely,\nBookstore ABC';

  // Send email with the invoice PDF to the customer
  sendEmailWithPDF(invoicePDFID, personID, 'Your Invoice from Bookstore ABC', emailBody, 'Bookstore ABC');
}

//send receipt to customer
function sendReceiptToCustomer(saleID, customerID) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row
  
  var sale = null;

  // Find the sale record by saleID and customerID
  data.forEach(function(row) {
    if (row[0] === saleID && row[1] === customerID) {
      sale = {
        saleID: row[0],
        customerID: row[1],
        customerName: row[2],
        customerEmail: row[15] // Assuming customerEmail is in the 16th column (index 15)
      };
    }
  });

  if (!sale) {
    Logger.log('Sale ID or Customer ID not found.');
    return;
  }

  // Generate the receipt
  var receiptInfo = generateReceiptsSale(saleID, customerID);
  if (!receiptInfo) {
    Logger.log('Receipt could not be generated.');
    return;
  }

  var receiptID = receiptInfo.receiptID;
  var pdfID = receiptInfo.pdfID;
  var pdfUrl = receiptInfo.pdfUrl;

  // Update the spreadsheet with the receipt ID and URL
  data.forEach(function(row, index) {
    if (row[0] === saleID && row[1] === customerID) {
      sheet.getRange(index + 2, 13).setValue(receiptID); // Receipt ID in the 13th column (index 12)
      sheet.getRange(index + 2, 14).setValue(pdfUrl); // Receipt URL in the 14th column (index 13)
    }
  });

  var personID = {
    name: sale.customerName,
    email: sale.customerEmail
  };

  var emailBody = 'Dear ' + sale.customerName + ',\n\nThank you for your purchase. Attached is your receipt. You can download it using the link below:\n\n' +
                  'Receipt: ' + pdfUrl + '\n\nSincerely,\nBookstore ABC';

  // Send email with the receipt PDF to the customer
  sendEmailWithPDF(pdfID, personID, 'Your Receipt from Bookstore ABC', emailBody, 'Bookstore ABC');

  deductStockFromSale(saleID);

  return{saleID: saleID, receiptID: receiptID, receiptInfo: receiptInfo}
}

//testing 
function testGenerateMonthlyReportHTML() {
  // Define the year and month you want to test
  const year = 2023;
  const month = 1;

  // Call the generateMonthlyReportHTML function and log the output
  const reportHTML = generateMonthlyReportHTML(year, month);
  Logger.log(reportHTML);
}

function testCreationFunctions() {
  var spreadsheetId = '1FXgkxBCoUZZFOC39nsOIuyqc13t1B5aslw7I4Nj7BZs';

  // Test Customer
  var customer = {
    name: 'John Doe',
    contact: '555-1234',
    address: '123 Elm Street',
    email: 'john.doe@example.com',
    notes: 'Preferred customer'
  };
  saveCustomerDetails(customer);

  // Test Supplier
  var supplier = {
    name: 'ABC Supplies',
    contact: '555-5678',
    address: '456 Oak Avenue',
    email: 'contact@abc-supplies.com'
  };
  saveSupplierDetails(supplier);

  // Test Product
  var product = {
    name: 'Widget',
    sku: 'W123',
    description: 'A useful widget',
    price: 19.99,
    stock: 100
  };
  saveProductDetails(product);

  // Test Procurement
  var inventoryID = 'INVT001'; // Should match an actual inventory ID in your test data
  var orderedAmount = 25;
  saveProcurementDetails(inventoryID, orderedAmount);

  //Test Inventory
  var inventory = {
    name: 'Widget Inventory',
    amount: 50,
    minLimit: 10,
    minLimitOrder: 20,
    supplierID: 'S1'
  };
  saveInventoryDetails(inventory);
  
  // Test Sale
  var sale = {
    customerID: 'C001', // Should match an actual customer ID in your test data
    customerName: 'John Doe',
    productInfo: [
      {
        sku: 'W123',
        name: 'Widget',
        quantity: 3,
        unitPrice: 19.99,
        totalAmount: 59.97
      }
    ],
    quantity: 3,
    unitPrice: 19.99,
    totalAmount: 59.97,
    paymentMethod: 'Credit Card',
    paymentStatus: 'Unpaid'
  };
  saveSaleDetails(sale);

  Logger.log('All test functions executed.');
}

function testGenerateInvoice() {
  var saleID = 'SL003';
  var sale = {
    customerID: 'C001',
    customerName: 'Lau Zheng Cheng',
    productInfo: [
      { sku: 'P001', name: 'Product 1', quantity: 2, unitPrice: 10.00, totalAmount: 20.00 },
      { sku: 'P002', name: 'Product 2', quantity: 1, unitPrice: 15.00, totalAmount: 15.00 }
    ],
    totalAmountBefore: 35.00,
    paymentMethod: 'Credit Card',
    paymentStatus: 'Unpaid'
  };

  var result = generateInvoice(saleID, sale);
  Logger.log('Generated Invoice Result: ' + JSON.stringify(result));
}

function testGenerateProcurementOrder() {
  var procurementID = 'PR001';
  var supplierID = 'S001';
  var companyName = 'ABC Corp';

  var result = generateProcurementOrder(procurementID, supplierID, companyName);
  Logger.log('Generated Procurement Order Result: ' + JSON.stringify(result));
}

function testGenerateReceiptsProcurement() {
  var procurementID = 'PR001';

  var result = generateReceiptsProcurement(procurementID);
  Logger.log('Generated Procurement Receipt Result: ' + JSON.stringify(result));
}

function testSaveSaleDetails() {
  // Sample sale object with multiple products
  var sale = {
    customerID: 'C001', // Ensure this matches an actual customer ID in your Customer Database
    customerName: 'John Doe',
    productInfo: [
      {
        sku: 'W123',
        name: 'Widget A',
        quantity: 2,
        unitPrice: 19.99,
        totalAmount: 39.98
      },
      {
        sku: 'W124',
        name: 'Widget B',
        quantity: 1,
        unitPrice: 29.99,
        totalAmount: 29.99
      },
      {
        sku: 'W125',
        name: 'Widget C',
        quantity: 3,
        unitPrice: 9.99,
        totalAmount: 29.97
      }
    ],
    quantity: 6, // Total quantity of all products
    unitPrice: 0, // Not used, as unit prices are in productInfo
    totalAmount: 99.94, // Total amount of all products
    paymentMethod: 'Credit Card',
    paymentStatus: 'Unpaid'
  };

  // Call the function with the sample sale data
  var result = combineSaveSaleAndGenerate(sale);

  // Log the result for verification
  Logger.log('Test Result: ' + JSON.stringify(result));
}

function testApproveProcurement() {
  // Use a known procurementID that exists in your test data
  var testProcurementID = 'PO006';
  // Call the function to test it
  approveProcurement(testProcurementID);
}

function testGenerateReceiptsSale() {
  var saleID = 'SL001';
  var customerID = 'C001';

  var result = generateReceiptsSale(saleID, customerID);
  Logger.log('Generated Receipt Result: ' + JSON.stringify(result));
}

function runAllTests() {
  // Test data for various entities
  var customer = {
    name: 'John Doe',
    contact: '555-1234',
    address: '123 Elm Street',
    email: 'john.doe@example.com',
    notes: 'Preferred customer'
  };
  
  var supplier = {
    name: 'ABC Supplies',
    contact: '555-5678',
    address: '456 Oak Avenue',
    email: 'contact@abc-supplies.com'
  };
  
  var product = {
    name: 'Widget',
    sku: 'W123',
    description: 'A useful widget',
    price: 19.99,
    stock: 100
  };
  
  var sale = {
    customerID: 'C001',
    customerName: 'John Doe',
    customerEmail: 'lauzhengcheng@gmail.com',
    productInfo: [
      { sku: 'W123', name: 'Widget A', quantity: 2, unitPrice: 19.99, totalAmount: 39.98 },
      { sku: 'W124', name: 'Widget B', quantity: 1, unitPrice: 29.99, totalAmount: 29.99 }
    ],
    quantity: 3,
    unitPrice: 0,
    totalAmount: 69.97,
    paymentMethod: 'Credit Card',
    paymentStatus: 'Unpaid'
  };
  
  var procurementID = 'PO006';
  var testInventoryID = 'INVT001';
  var orderedAmount = 50;
  
  // Test saving functions
  saveCustomerDetails(customer);
  saveSupplierDetails(supplier);
  saveProductDetails(product);
  saveSaleDetails(sale);
  saveProcurementDetails(testInventoryID, orderedAmount);
  
  // Test procurement approval and payment functions
  approveProcurement(procurementID);
  payProcurement(procurementID, 'Paid');
  
  // Test sending invoice (auto) and receipt to customer
  var saleID = 'SL002';
  var customerID = 'C001';
  sendReceiptToCustomer(saleID, customerID);
  
  // // Test generation functions
  // var year = 2023;
  // var month = 1;
  // var reportHTML = generateMonthlyReportHTML(year, month);
  // Logger.log(reportHTML);
  
  testGenerateInvoice();
  testGenerateReceiptsSale();
  testGenerateProcurementOrder();
  testPayProcurement();
  testConfirmProcurement();
  
  Logger.log('All tests executed.');
}

function testForecast() {
  var numberMonth = 2;
  forecastSales(numberMonth);
}

///////////////
function forecastSales(numMonths) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Sales Database");
    if (!sheet) {
      return { error: "Sheet 'Sales Database' not found." };
    }
    var data = sheet.getDataRange().getValues();
    if (!data || data.length === 0) {
      return { error: "No data found in the sheet." };
    }

    var products = {};
    data = data.slice(1); // Remove header
    data.sort(function(a, b) {
      return new Date(a[14]) - new Date(b[14]); // Sort by date in column O (index 14)
    });

    for (var i = 0; i < data.length; i++) {
      if (data[i][14] && data[i][3] && data[i][5] && data[i][6]) {
        var date = new Date(data[i][14]);
        var product = data[i][3];
        var quantity = Number(data[i][5]);
        var unitPrice = Number(data[i][6]);

        if (!products[product]) {
          products[product] = { dates: [], quantities: [], unitPrices: [] };
        }
        products[product].dates.push(date.getTime());
        products[product].quantities.push(quantity);
        products[product].unitPrices.push(unitPrice);
      }
    }

    var forecastData = [];
    var currentDate = new Date(data[data.length - 1][14]);

    for (var i = 1; i <= numMonths; i++) {
      var futureDate = new Date(currentDate);
      futureDate.setMonth(futureDate.getMonth() + 1);

      for (var product in products) {
        if (products[product].dates.length > 1) {
          var regressionResult = linearRegression(products[product].dates, products[product].quantities);
          var forecastedQuantity = Math.round(regressionResult.slope * futureDate.getTime() + regressionResult.intercept);
          var forecastedTotalPrice = Math.round(forecastedQuantity * products[product].unitPrices[0]);

          forecastData.push({
            date: formatDate(futureDate),
            productName: product,
            quantity: forecastedQuantity,
            totalAmount: forecastedTotalPrice
          });

          products[product].dates.push(futureDate.getTime());
          products[product].quantities.push(forecastedQuantity);
        } else {
          // Handle insufficient data for regression
        }
      }
      currentDate = futureDate;
    }

    var result = {
      forecastData: forecastData,
      startDate: formatDate(new Date(data[data.length - 1][14])),
      endDate: formatDate(currentDate)
    };

    // Write the forecast data to the "Sales Forecast" sheet
    var forecastSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Sales Forecast");
    if (!forecastSheet) {
      forecastSheet = SpreadsheetApp.getActiveSpreadsheet().insertSheet("Sales Forecast");
    } else {
      clearForecastSheet(forecastSheet);
    }
    
    // Set headers
    forecastSheet.appendRow(["Date", "Product Name", "Quantity", "Total Amount"]);
    
    // Append forecast data
    forecastData.forEach(row => {
      forecastSheet.appendRow([row.date, row.productName, row.quantity, row.totalAmount]);
    });

    return result;

  } catch (error) {
    return { error: error.message };
  }
}

function linearRegression(x, y) {
  var n = x.length;
  if (n < 2) throw new Error("Not enough data points for regression.");

  var sum_x = 0;
  var sum_y = 0;
  var sum_xy = 0;
  var sum_xx = 0;

  for (var i = 0; i < n; i++) {
    sum_x += x[i];
    sum_y += y[i];
    sum_xy += x[i] * y[i];
    sum_xx += x[i] * x[i];
  }

  var slope = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x);
  var intercept = (sum_y - slope * sum_x) / n;

  if (isNaN(slope) || isNaN(intercept)) throw new Error("Invalid regression calculation.");

  return { slope: slope, intercept: intercept };
}

function formatDate(date) {
  var day = String(date.getDate()).padStart(2, '0');
  var month = String(date.getMonth() + 1).padStart(2, '0');
  var year = date.getFullYear();
  return year + '-' + month + '-' + day;
}

function clearForecastSheet(sheet) {
  var lastRow = sheet.getLastRow();
  if (lastRow > 0) {
    sheet.clear();  // Clears all the content of the sheet
  }
}
///////////////


function testPayProcurement() {
  var result = payProcurement('PO006');
  Logger.log(result); // Log the result to verify the output
}

function testConfirmProcurement() {
  var result = confirmProcurement('PO006'); // Replace 'P001' with the actual procurement ID you want to test
  Logger.log(result); // Log the result to verify the output
}

function testSendReceiptToCustomer() {
  // Existing sale ID and customer ID to test
  var saleID = 'SL002'; // Replace with an actual sale ID from your spreadsheet
  var customerID = 'C001'; // Replace with an actual customer ID from your spreadsheet

  // Run the sendReceiptToCustomer function
  sendReceiptToCustomer(saleID, customerID);

  // Check the Sales Database for receipt details
  var salesSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  var updatedSalesData = salesSheet.getDataRange().getValues();
  Logger.log('Updated Sales Data: ' + JSON.stringify(updatedSalesData));
}

function getUnpaidSales() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  const data = sheet.getDataRange().getValues();
  const unpaidSales = new Set();

  data.forEach((row, index) => {
    if (index > 0 && row[9] === 'Unpaid') { // Assuming Payment Status is in the 10th column (index 9)
      unpaidSales.add(row[0]); // Adding Sale ID to the set
    }
  });

  return Array.from(unpaidSales).map(saleID => ({ saleID }));
}

function updatePaymentStatus(saleID, status) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database');
  const data = sheet.getDataRange().getValues();
  let customerID = null;

  data.forEach((row, index) => {
    if (row[0] === saleID) {
      sheet.getRange(index + 1, 10).setValue(status); // Assuming Payment Status is in the 10th column (index 9)
      customerID = row[1]; // Assuming Customer ID is in the 2nd column (index 1)
    }
  });

  if (status === 'Paid' && customerID) {
    sendReceiptToCustomer(saleID, customerID);
  }
}

function autoCheck() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Inventory Database");
  var data = sheet.getDataRange().getValues();
  
  // Assuming the columns are as follows:
  // Column 1: Inventory ID
  // Column 2: Inventory Name
  // Column 3: Inventory Amount
  // Column 4: Inventory Reorder Point
  // Column 5: Reorder Quantity (Auto)
  // Column 6: Supplier ID
  // Column 7: Supplier Name
  // Column 8: Supplier Email

  // Loop through the data, skipping the header row
  for (var i = 1; i < data.length; i++) {
    var inventoryID = data[i][0];
    var inventoryName = data[i][1];
    var currentStock = data[i][2];
    var reorderPoint = data[i][3];
    var reorderQuantity = data[i][4];
    
    // Check if the current stock is below or equal to the reorder point
    if (currentStock <= reorderPoint) {
      // Save procurement details for this inventory
      saveProcurementDetails(inventoryID, reorderQuantity);
      Logger.log('Procurement order created for ' + inventoryName + ' (ID: ' + inventoryID + ') with amount: ' + reorderQuantity);
    }
  }
}

function testAutoCheck(){
  autoCheck();
}

function getUnpaidRestockData() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var result = [];
  
  for (var i = 1; i < data.length; i++) { // Skip header row
    if (data[i][11] === 'Pending') { // Assuming Approval Status is in the 12th column
      result.push([data[i][0], data[i][1], data[i][2], data[i][3]]); // Push Procurement ID, Inventory ID, Inventory Name, Ordered Quantity
    }
  }
  
  return result;
}

function updateRestockStatus(id, status) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Procurement Database');
  var data = sheet.getDataRange().getValues();
  var headers = data.shift(); // Remove header row

  data.forEach(function(row, index) {
    if (row[1] == id) { // Assuming 'Inventory ID' is in the 2nd column (index 1)
      Logger.log('Updating row for ID: ' + id + ' with status: ' + status);
      if (status == 'Approved') {
        row[11] = 'Approved'; // Assuming 'Approval Status' is in the 12th column (index 11)
        row[12] = 'Unpaid';   // Ensuring 'Payment Status' remains 'Unpaid'
      } else if (status == 'Rejected') {
        row[11] = 'Rejected';
        row[12] = 'Rejected';
      } else if (status == 'Paid') {
        row[12] = 'Paid';    // Assuming 'Payment Status' is in the 13th column (index 12)
      }
      sheet.getRange(index + 2, 1, 1, row.length).setValues([row]);
    }
  });
}

function testDoPost() {
  var e = {
    parameter: {
      numMonths: 3 // or any number you want to test with
    }
  };
  var result = doPost(e);
  Logger.log(result.getContent()); // Log the result content
}


function getSpreadsheetData() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sales Database'); // Replace 'Sales Database' with your sheet name
  if (!sheet) {
    Logger.log("Sheet not found.");
    return [];
  }
  var data = sheet.getDataRange().getValues();
  Logger.log(data); // Log the data to verify it's being fetched
  return data;
}
